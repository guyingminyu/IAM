CREATE PROCEDURE auto_api.P_api_project()
  BEGIN
	#Routine body goes here...
DECLARE a INT(5);
declare b int(5);
DECLARE strn VARCHAR(255);
DECLARE strh VARCHAR(255) DEFAULT 'qaapi.paomianfan.com';
DECLARE strp VARCHAR(255) DEFAULT '80';	
	set a = (SELECT MAX(id) from api_project );
	set b = a+10;
	while a<b DO
	set a = a+1;
	set strn = CONCAT('projectname',CONCAT(LPAD(a,5,0)));
	INSERT into api_project VALUES(a,strn,strh,strp);
	END WHILE;
END;
